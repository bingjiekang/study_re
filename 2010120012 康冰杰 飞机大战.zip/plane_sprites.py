import random
import pygame as pg

SCREEN_RECT = pg.Rect(0,0,500,700)

FRAME_PER_SEC = 60

CREATE_ENEMY_EVENT = pg.USEREVENT

HERO_FIRE_EVENT = pg.USEREVENT + 1

class GameSprite(pg.sprite.Sprite):

    def __init__(self,image_name,speed=1):

        super().__init__()

        self.image = pg.image.load(image_name)
        self.rect = self.image.get_rect()
        self.speed = speed

    def update(self):
        self.rect.y += self.speed


class Background(GameSprite):

    def __init__(self, is_alt = False):

        super().__init__(".\图片素材\背景图片4.jfif")

        if is_alt:
            self.rect.y = -self.rect.height


    def update(self):

        super().update()

        if self.rect.y >=SCREEN_RECT.height:
            self.rect.y = -self.rect.height


class Enemy(GameSprite):
    def __init__(self):

        i = random.randint(0,17)
        if i==0:
            super().__init__(".\图片素材\dr0.png")
        elif i==1:
            super().__init__(".\图片素材\dr1.png")
        elif i==2:
            super().__init__(".\图片素材\dr2.png")
        elif i==3:
            super().__init__(".\图片素材\dr3.png")
        elif i==4:
            super().__init__(".\图片素材\dr4.png")
        elif i==5:
            super().__init__(".\图片素材\dr5.png")
        elif i==6:
            super().__init__(".\图片素材\dr6.png")
        elif i==7:
            super().__init__(".\图片素材\dr7.png")
        elif i==8:
            super().__init__(".\图片素材\dr8.png")
        elif i==9:
            super().__init__(".\图片素材\dr9.png")
        elif i==10:
            super().__init__(".\图片素材\dr10.png")
        elif i==11:
            super().__init__(".\图片素材\dr11.png")
        elif i==12:
            super().__init__(".\图片素材\dr12.png")
        elif i==13:
            super().__init__(".\图片素材\dr13.png")
        elif i==14:
            super().__init__(".\图片素材\dr14.png")
        elif i==15:
            super().__init__(".\图片素材\dr15.png")
        elif i==16:
            super().__init__(".\图片素材\dr16.png")
        elif i==17:
            super().__init__(".\图片素材\dr17.png")


        self.speed = random.randint(2,10)

        self.rect.bottom = 0

        max_x = SCREEN_RECT.width - self.rect.width
        self.rect.x = random.randint(0,max_x)
    def update(self):

        super().update()
        
        if self.rect.y >= SCREEN_RECT.height:
        #    print("sc")
            self.kill()

class Hero(GameSprite):

    def __init__(self):

        super().__init__(".\图片素材\hero.png",0)

        self.rect.centerx = SCREEN_RECT.centerx
        self.rect.bottom = SCREEN_RECT.bottom - 10

        self.bullets = pg.sprite.Group()

    def update(self):

        self.rect.x += self.speed

        if self.rect.x < 0:
            self.rect.x = 0
        elif self.rect.right > SCREEN_RECT.right:
            self.rect.right = SCREEN_RECT.right
    def fire(self):
        for i in range(3):

            bullet = Bullet()
            bullet.rect.bottom = self.rect.y - i*10
            bullet.rect.centerx = self.rect.centerx

            self.bullets.add(bullet)



class Bullet(GameSprite):
    def __init__(self):
        super().__init__(".\图片素材\一个弹.png",-4)

    def update(self):
        super().update()
        if self.rect.bottom<0:
            self.kill()